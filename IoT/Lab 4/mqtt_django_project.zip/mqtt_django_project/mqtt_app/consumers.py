# mqtt_app/consumers.py

import asyncio
from channels.generic.websocket import AsyncWebsocketConsumer
import paho.mqtt.client as mqtt

class MQTTConsumer(AsyncWebsocketConsumer):
    async def connect(self):
        await self.accept()
        self.client = mqtt.Client()
        self.client.on_connect = self.on_connect
        self.client.on_message = self.on_message
        self.client.connect("broker.hivemq.com", 1883, 60)  # Replace with your MQTT broker address
        self.client.subscribe("cuztomas")  # Replace with your MQTT topic
        self.client.loop_start()

    def on_connect(self, client, userdata, flags, rc):
        print("Connected with result code "+str(rc))

    def on_message(self, client, userdata, msg):
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        loop.run_until_complete(self.send_message(msg.payload.decode()))
        #asyncio.run(self.send_message(msg.payload.decode()))

    async def send_message(self, message):
        await self.send(text_data=message)

