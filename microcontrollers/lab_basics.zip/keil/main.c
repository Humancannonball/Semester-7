#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

unsigned long long reverse_bits_64(unsigned long long);

unsigned int crc32Calc(unsigned char *message) {
   int i, j;
   unsigned int byte, crc, mask;

   i = 0;
   crc = 0xFFFFFFFF;
   while (message[i] != 0) {
      byte = message[i];            // Get next byte.
      crc = crc ^ byte;
      for (j = 7; j >= 0; j--) {    // Do eight times.
         mask = -(crc & 1);
         crc = (crc >> 1) ^ (0xEDB88320 & mask);
      }
      i = i + 1;
   }
   return ~crc;
}

void svcCall(void)
{
    __asm( "svc #0" );
}

unsigned int reverseBits(unsigned int value)
{
    __asm( "RBIT 	r0, r0" );
}


void memCopy(void *dst, void *src, unsigned n);

int main() {
	
	// Step 1
	svcCall();

	
	// Step 2
	unsigned int value = 0xCAFED00D;
	unsigned int valueReversed = reverseBits(value);

	printf("Reversed bits of 0x%08X is 0x%08X. Operation ", value, valueReversed);
	if (valueReversed == 0xB00B7F53) {
		printf("success :)\n");
	} else {
		printf("failed :(\n");
	}
	
	
	// Step 3
	const char *message = "Here is message";
	unsigned crc = crc32Calc(message);
	printf("crc32=0x%08X of message:'%s'\n", crc, message);
	
	
	// Step 4
	unsigned long long val64 = 0xF800000300000001ULL;
	unsigned long long rev_val64 = reverse_bits_64(val64);
	printf("Reversed bits of 0x%016llX is 0x%016llX\n", val64, rev_val64);

	
	// Step 5
	#define N 256
	char dst[N];
	char src[N];
	for (int i = 0; i < N; i++) {
		src[i] = i;
		dst[i] = 0;
	}
	memcpy(dst, src, N);
	
	for(;;);
  return 0;
}


void simple_function(int n)
{
	int memory[1000];
	
}